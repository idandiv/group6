from db_connector import get_list_of_customers, insert_user, get_users_collection,get_Trips_collection,get_reviwes_collection,get_contact_us_collection,get_favorites_collection,insert_user

def print_collection(collection):
    count = collection.count_documents({})
    if count == 0:
        print("No documents found in the collection.")
    else:
        documents = collection.find()
        for document in documents:
            print(document)
#
# def addtoMONGODB():
#      my_dict = {
#          'name': 'John',
#          'address': 'Highway 37',
#          'rating': 10
#     }
#      insert_user(my_dict)


if __name__ == "__main__":
    print("Trips Collection:")
    Trips_col = get_Trips_collection()
    print_collection(Trips_col)

    print("Users Collection:")
    users_col = get_users_collection()
    print_collection(users_col)

    print("Reviews Collections:")
    reviews_col = get_reviwes_collection()
    print_collection(reviews_col)

    print("Contact_us Collection:")
    contact_us_col = get_contact_us_collection()
    print_collection(contact_us_col)

    print("Favorites Collection:")
    favorites_col = get_favorites_collection()
    print_collection(favorites_col)




