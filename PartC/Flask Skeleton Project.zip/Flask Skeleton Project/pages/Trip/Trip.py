from flask import Blueprint, render_template
from bson.objectid import ObjectId
from db_connector import get_trip_by_id

Trip = Blueprint('Trip', __name__, static_folder='static',static_url_path='/trip' ,template_folder='templates')


@Trip.route('/Trip')
def index():
    return render_template('trip.html')


@Trip.route('/trip/<trip_id>')
def trip_view(trip_id):
    trip = get_trip_by_id(ObjectId(trip_id))
    if trip:
        return render_template('Trip.html', trip=trip)
    return "Trip not found", 404


