from flask import Blueprint, render_template

# about blueprint definition
Reviews = Blueprint(
    'Reviews',
    __name__,
    static_folder='static',
    static_url_path='/Reviews',
    template_folder='templates'
)




@Reviews.route('/Reviews')
def index():
    return render_template('Reviews.html')


