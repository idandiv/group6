from flask import Blueprint, render_template, request, redirect, url_for
from db_connector import get_users_collection, insert_user

SignUp = Blueprint('SignUp', __name__, static_folder='static', static_url_path='/SignUp', template_folder='templates')

@SignUp.route('/SignUp')
def index():
    return render_template('SignUp.html')

users_collection = get_users_collection()

@SignUp.route('/SignUp/submit', methods=['POST'])
def signup():

    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        age = request.form.get('age')
        phone = request.form.get('phone')
        gender = request.form.get('gender')
        country = request.form.get('country')

        new_user = {
            'name': name,
            'email': email,
            'age': age,
            'phone': phone,
            'gender': gender,
            'country': country
        }
        print("New user data:", new_user)
        try:
            insert_user(new_user)
            print("User inserted successfully!")
        except Exception as e:
            print(f"An error occurred while inserting the user: {e}")

        return redirect(url_for('home'))
    return render_template('SignUp.html')
