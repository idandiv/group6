from flask import Blueprint, render_template
from db_connector import get_trips_collection, get_reviwes_collection

# catalog blueprint definition
catalog = Blueprint('catalog', __name__, static_folder='static', static_url_path='/catalog',
                    template_folder='templates')


# Routes
@catalog.route('/catalog')
def index():
    trips_collection = get_trips_collection()
    reviews_collection = get_reviwes_collection()

    trips = list(trips_collection.find())
    for trip in trips:
        trip['reviews'] = list(reviews_collection.find({'TripID': trip['TripID']}))

    return render_template('catalog.html', trips=trips)
