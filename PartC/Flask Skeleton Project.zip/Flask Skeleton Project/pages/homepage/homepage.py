from flask import Blueprint, render_template, request, redirect, url_for
from db_connector import get_trip_by_name

homepage = Blueprint('homepage', __name__, static_folder='static', static_url_path='/', template_folder='templates')


@homepage.route('/')
def index():
    return render_template('homepage.html')

@homepage.route('/trip/search')
def search_trip():
    query = request.args.get('query')
    if query:
        trip = get_trip_by_name(query)
        if trip:
            return redirect(url_for('Trip.trip_view', trip_id=str(trip['_id'])))
    return "Trip not found", 404
