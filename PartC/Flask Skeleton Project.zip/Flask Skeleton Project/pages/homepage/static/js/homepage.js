        document.getElementById('searchButton').addEventListener('click', function() {
            const query = document.getElementById('searchInput').value;
            window.location.href = `/trip/search?query=${query}`;
        });