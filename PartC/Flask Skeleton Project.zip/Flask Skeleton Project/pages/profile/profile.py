from flask import Blueprint, render_template, session, redirect, url_for, request
from db_connector import get_users_collection

profile = Blueprint(
    'profile', __name__,
    static_folder='static',
    static_url_path='/profile',
    template_folder='templates')


@profile.route('/profile')
def index():
    try:
        user = session.get('user')
        if not user:
            return redirect(url_for('login.index'))
        return render_template('profile.html', user=user)
    except Exception as e:
        print(f"An error occurred: {e}")
        return redirect(url_for('profile.index'))


@profile.route('/profile/update', methods=['POST'])
def update_user():
    try:
        user = session.get('user')
        if not user:
            return redirect(url_for('login.index'))

        user_data = {
            'name': request.form['name'],
            'email': request.form['email'],
            'age': request.form['age'],
            'phone': request.form['phone'],
            'gender': request.form['gender'],
            'country': request.form['country']
        }

        get_users_collection().update_one({'email': user['email']}, {'$set': user_data})
        session['user'] = user_data  # עדכן את הנתונים במשתמש הנוכחי שב-Session

        return redirect(url_for('profile.index'))
    except Exception as e:
        print(f"An error occurred: {e}")
        return redirect(url_for('profile.index'))


@profile.route('/profile/delete', methods=['POST'])
def delete_user():
    try:
        user = session.get('user')
        if not user:
            return redirect(url_for('login.index'))

        get_users_collection().delete_one({'email': user['email']})
        session.pop('user', None)  # הסר את המשתמש מה-Session

        return redirect(url_for('login.index'))
    except Exception as e:
        print(f"An error occurred: {e}")
        return redirect(url_for('profile.index'))


@profile.route('/profile/logout', methods=['POST'])
def logout():
    session.pop('user', None)  # הסר את המשתמש מה-Session
    return redirect(url_for('login.index'))
