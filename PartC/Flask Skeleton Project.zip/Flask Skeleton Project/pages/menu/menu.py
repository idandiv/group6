from flask import render_template, Blueprint, request, redirect, url_for, session
from db_connector import get_contact_us_collection

# about blueprint definition
menu = Blueprint(
    'menu',
    __name__,
    static_folder='static',
    static_url_path='/menu',
    template_folder='templates'
)

# Routes
@menu.route('/contact_us')
def index():
    return render_template('menu.html')

@menu.route('/menu/contact', methods=['POST'])
def contact():
    try:
        name = request.form.get('name')
        email = request.form.get('email')
        message = request.form.get('message')
        print(f"Received contact form submission: name={name}, email={email}, message={message}")

        contact_us_collection = get_contact_us_collection()
        new_message = {
            'name': name,
            'email': email,
            'message': message
        }
        contact_us_collection.insert_one(new_message)
        print("Message inserted successfully!")
        return redirect(url_for('menu.index', success=True))
    except Exception as e:
        print(f"An error occurred: {e}")
        return redirect(url_for('menu.index', success=False))
