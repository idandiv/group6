from flask import Blueprint, render_template, request, redirect, url_for, session
from bson import ObjectId
from db_connector import get_users_collection

# about blueprint definition
login = Blueprint(
    'login',
    __name__,
    static_folder='static',
    static_url_path='/login',
    template_folder='templates'
)

# Routes
@login.route('/login')
def index():
    return render_template('login.html')

@login.route('/login', methods=['POST'])
def login_user():
    try:
        email = request.form.get('email')
        name = request.form.get('name')
        print(f"Received login attempt: name={name}, email={email}")
        users_collection = get_users_collection()
        user = users_collection.find_one({'email': email, 'name': name})

        if user:
            user['_id'] = str(user['_id'])
            session['user'] = user
            print("User found, redirecting to profile")
            return redirect(url_for('profile.index'))
        else:
            print("User not found")
            return render_template('login.html', error="User not found. Please sign up.")
    except Exception as e:
        print(f"An error occurred: {e}")
        return render_template('login.html', error="An unexpected error occurred. Please try again.")
