document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            event.preventDefault();
            if (validateForm()) {
                loginForm.submit();  // Submit the form after validation
            }
        });
    } else {
        console.error('Login form not found');
    }
});

// Function to display messages using Bootstrap alerts
function displayMessage(message, type) {
    const messageContainer = document.createElement('div');
    messageContainer.classList.add('alert', `alert-${type}`);
    messageContainer.innerHTML = message;
    document.querySelector('.login-form').prepend(messageContainer);

    setTimeout(() => {
        messageContainer.remove();
    }, 5000);
}

// Function to validate form inputs
function validateForm() {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;

    let errors = [];

    // ניקוי הודעות שגיאה קודמות
    const existingErrors = document.querySelectorAll('.error-container, .alert');
    existingErrors.forEach(error => error.remove());

    // Validate name
    if (name.trim() === '') {
        errors.push('Name is required');
    }

    // Validate email
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if (!emailPattern.test(email)) {
        errors.push('Invalid email address');
    }

    // Display errors or success message
    if (errors.length > 0) {
        displayMessage(errors.join('<br>'), 'danger');
        return false;  // Form is not valid
    } else {
        displayMessage('Login successful!', 'success');
        return true;  // Form is valid
    }
}
