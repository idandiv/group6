import os

import pymongo
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
# from db_connector import *

uri = "mongodb+srv://IdoIdanWeb:Ido12490@idospitzer.qs4v0xx.mongodb.net/?retryWrites=true&w=majority&appName=IdoSpitzer"

# Create a new client and connect to the server
client = MongoClient(uri, server_api=ServerApi('1'))

# Send a ping to confirm a successful connection
try:
    client.admin.command('ping')
    print("Pinged your deployment. You successfully connected to MongoDB!")
except Exception as e:
    print(e)

# get all dbs and collestions that needed
Sample_db = client['sample_mflix']
users_col = Sample_db['users']
trips_col = Sample_db['trips']

def update_user_details(user_email, user_data):
    users_collection = get_users_collection()
    users_collection.update_one({'email': user_email}, {'$set': user_data})

def delete_user(user_email):
    users_collection = get_users_collection()
    users_collection.delete_one({'email': user_email})


def get_trip_by_name(name):
    return trips_col.find_one({'Name': name})

def get_trip_by_id(trip_id):
    return trips_col.find_one({'_id': trip_id})
def get_Trips_collection():
    return Sample_db['trips']
def get_trips_collection():
    return Sample_db['trips']


def get_users_collection():
    return Sample_db['users']

def get_reviwes_collection():
    return Sample_db['reviews']

def get_contact_us_collection():
    return Sample_db['contact_us']

def get_favorites_collection():
    return Sample_db['favorites']


# create all necessary functions
def get_list_of_customers():
    return list(users_col.find())


def insert_user(user_dict):
    users_col.insert_one(user_dict)



#@menu.route('/menu') # we got no menu page
#def index():
#message = get_list_of_customers()
#customers_names = [c['name'] for c
# n message]
#return render_template('menu.html', message=customers_names)

# ...


